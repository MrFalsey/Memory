const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());

// Opprett en MySQL-forbindelse
const db = mysql.createConnection({
    host: 'localhost',
    user: 'Memory', // Endre til din MySQL-bruker
    password: 'Memory1', // Endre til ditt MySQL-passord
    database: 'memory_game'
});

db.connect((err) => {
    if (err) throw err;
    console.log('Connected to MySQL database');
});

app.use(express.static(path.join(__dirname, 'public')));

// Hent kortdata fra databasen
app.get('/api/cards', (req, res) => {
    const query = 'SELECT * FROM cards';
    db.query(query, (err, results) => {
        if (err) {
            return res.status(500).send('Database error');
        }
        res.json(results);
    });
});

// Start serveren
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});